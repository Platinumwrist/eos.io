#pragma once

namespace eosio { namespace chain { namespace eosvmoc {

void run_compile_trampoline(int fd);

}}}