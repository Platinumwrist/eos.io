#pragma once
#include <eosio/chain/block.hpp>
